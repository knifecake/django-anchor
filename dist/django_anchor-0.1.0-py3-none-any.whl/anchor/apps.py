from django.apps import AppConfig


class AnchorConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "anchor"
    verbose_name = "Anchor"
